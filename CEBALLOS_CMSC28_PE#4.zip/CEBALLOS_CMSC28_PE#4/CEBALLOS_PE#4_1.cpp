/* WRITTEN BY: 	CEBALLOS, CRISTIENEIL J. (K-3L)
					
	PROGRAMMING EXERCISE 04 - C++ WARM UP EXERCISE PROBLEM 1
	A C++ PROGRAM THAT DETERMINES THE HIGHEST AND LOWEST VALUE AMONG THREE NUMBERS 
	AND GETS THE DIFFERENCE OF THE TWO (HIGHEST - LOWEST) */

	#include <iostream>
	
	using namespace std;
	
	void program_desc();
	void user_input(float&, float&, float&);
	float highestval(float, float, float);
	float lowestval(float, float, float);
	void print_result(float, float, float, float, float, float);
		
		
	// MAIN PROGRAM
	int main() 
	{
		// variable declaration
		float x, y, z;
		
		// function call for program description
		program_desc();
		
		// read the user's input
		user_input(x, y, z);
		
		// get the largest value
		float largest = highestval(x, y, z);
		
		// get the smallest value
		float smallest = lowestval(x, y, z);
		
		// get the difference of the highest and lowest values
		float difference = largest - smallest;
			
		// display all the values - three numbers from user-input, lagest value, smallest value, and the difference of the 2
		print_result(x, y, z, largest, smallest, difference);
	}
	
	// function for program description
	void program_desc()
	{
		cout << "\n\t This program asks the user to input three (3) numbers and find" << endl;
		cout << "\t the highest and lowest number, and output their difference. \n" << endl;
		cout << "............................................................................. \n" << endl;
		
		// about the programmer: name, date done, subject number
		cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: APR 27 2024 | SUBJ: CMSC 28 \n" << endl;
		cout << "============================================================================= \n" << endl;
	}
	
	// function to let user input
	void user_input(float &num1, float &num2, float &num3)
	{
		cout << "\n\t Enter the first number: ";
		cin >> num1;
		
		cout << "\t Enter the first number: ";
		cin >> num2;
		
		cout << "\t Enter the first number: ";
		cin >> num3;
	}
	
	// function to determine the largest value among the three numbers
	float highestval(float num1, float num2, float num3)
	{
		float largestnum = num1;
		
		if (num2 > largestnum) 
		{
			largestnum = num2;
		}
	
		if (num3 > largestnum)
		{
			largestnum = num3;
		}
		
		return largestnum;
	}
	
	// function to determine the smallest value among the three numbers
	float lowestval(float num1, float num2, float num3)
	{
		float smallestnum = num1;
		
		if (num2 < smallestnum)
		{
			smallestnum = num2;
		}
		
		if (num3 < smallestnum)
		{
			smallestnum = num3;
		}
		
		return smallestnum;
	}
	
	// function to display all the values
	void print_result(float num1, float num2, float num3, float largest, float smallest, float difference) 
	{
	    cout << "\n\t < THE VALUES > " << endl;
	    cout << "\t Number 1: " << num1 << endl;
	    cout << "\t Number 2: " << num2 << endl;
	    cout << "\t Number 3: " << num3 << endl;
	    
	    cout << "\n\t > Largest number: " << largest << endl;
	    cout << "\t > Smallest number: " << smallest << endl;
	    cout << "\t > Difference: " << difference << endl;
	}
