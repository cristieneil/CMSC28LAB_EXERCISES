/* WRITTEN BY: 	CEBALLOS, CRISTIENEIL J. (K-3L)
					
	PROGRAMMING EXERCISE 04 - C++ WARM UP EXERCISE PROBLEM 2
	A C++ PROGRAM THAT ASKS THE USER TO INPUT AN INTEGER AND THEN 
	PROVIDE ITS BINARY EQUIVALENT */

	#include <iostream>
	#include <string>
	
	using namespace std;
	
	void program_desc();
	void user_input(int&);
	string decimalToBinaryConversion(int);
	void print_result(int, string);
	
	int main() 
	{
	    int decimal;
	    
	    program_desc();
	    
	    user_input(decimal);
	
	    string binarynum = decimalToBinaryConversion(decimal);
	
	    print_result(decimal, binarynum);
	    
	    return 0;
	}
	
	void program_desc()
	{
	    cout << "\n\t This program asks the user to input an integer and then" << endl;
	    cout << "\t provides its binary equivalent. \n" << endl;
	    cout << "............................................................................. \n" << endl;
	    
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: APR 27 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	    cout << "\t DECIMAL TO BINARY CONVERSION \n0"<< endl;
	}
	
	void user_input(int &num)
	{
	    cout << "\t Enter number: ";
	    cin >> num;
	}
	
	string decimalToBinaryConversion(int num) 
	{
		// if number is equal to zero, return 0 to the main program
	    if (num == 0)
	    {
	        return "0";
	    }
	
		// if number is greater than 0
	    string binary; 	// initialize an empty string to store the binary conversion
	    while (num > 0) 
	    {
	    	// if number is divisible by 2, add '0' to the beginning of the string, otherwise, add '1'
	        binary = (num % 2 == 0 ? "0" : "1") + binary;
	        num /= 2;
	    }
	    
	    // return the binary conversion of the number to the main program
	    return binary;
	}
	
	void print_result(int num, string binarynum)
	{
	    cout << "\n\t < THE VALUES > " << endl;
	    cout << "\n\t Decimal (base 10): " << num << endl;
	
	    cout << "\t Binary (base 2): " << binarynum << endl;
	}

