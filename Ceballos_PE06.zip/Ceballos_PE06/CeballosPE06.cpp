/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L 
	PROGRAMMING EXERCISE 06 - OOP 2
	A C++ PROGRAM THAT ASKS THE USER TO INPUT THE MOVIE DETAILS AND MAKE A LIST. 
	THE LIST IS IMPLEMENTED USING ARRAY */

	#include <iostream>
	#include <string>
	#include <cctype>
	#include "movie.h" // movie.h as header file
	#include "Person.h" // person.h as header file
	
	using namespace std;
	
	// MAIN PROGRAM
	int main() {
	    // for the array
	    const int MAX_SIZE = 10; // set maximum size of array
	    Movie LIST[MAX_SIZE]; // create instance for class movie
	    int count = 0; // to take note of the current array size/count
	    char choice;
	
	    string title, synopsis, rating, genre;
	    string dirfname, dirlname;
	    string actfname, actlname;
	    char dirgender, actgender;
	
	    // program header and desc
	    cout << "\n\t This program will ask the user to input movie title, synopsis, mpaa rating, " << endl;
	    cout << "\t genre, including its director/s and actors, and then display it afterwards \n" << endl;
	    cout << "............................................................................. \n" << endl;
	
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 18 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	
	    do {
	        // checks if array is full
	        if (count >= MAX_SIZE) {
	            cout << "\n\t Movie list is FULL. No more entries can be added." << endl;
	            break;
	        }
	
	        cout << "\n\t < ALL ABOUT THAT MOVIE > \n" << endl;
	
	        // lets user to input movie details
	        cout << "\t Enter Movie Title: ";
	        getline(cin, title);
	
	        cout << "\t Enter Movie Synopsis: ";
	        getline(cin, synopsis);
	
	        cout << "\t MPAA Rating (G, PG, PG-13, R, NC-17): ";
	        getline(cin, rating);
	
	        cout << "\t Movie Genre: ";
	        getline(cin, genre);
	
	        // lets user to input details about the respective directo/s and actor/s
	        cout << "\n\t < ALL ABOUT THE DIRECTOR/S > \n" << endl;
	
	        cout << "\t First Name: ";
	        getline(cin, dirfname);
	
	        cout << "\t Last Name: ";
	        getline(cin, dirlname);
	
	        cout << "\t Gender (F | M): ";
	        cin >> dirgender;
	        dirgender = toupper(dirgender); // to convert user-input to uppercase
	
	        Person director(dirfname, dirlname, dirgender);
	
	        // clear the newline character left in the buffer by cin
	        cin.ignore();
	
	        cout << "\n\t < ALL ABOUT THE MAIN CHARACTERS > \n" << endl;
	
	        cout << "\t First Name: ";
	        getline(cin, actfname);
	
	        cout << "\t Last Name: ";
	        getline(cin, actlname);
	
	        cout << "\t Gender (F | M): ";
	        cin >> actgender;
	        actgender = toupper(actgender); // to convert user-input to uppercase
	
	        Person actor(actfname, actlname, actgender);
	
	        // clear the newline character left in the buffer by cin
	        cin.ignore();
	
	        // Create Movie object and add to list
	        LIST[count] = Movie(title, synopsis, rating, genre, director, actor);
	        count++;
	
	        // Display the inputted information
	        cout << "\n\t ----- MOVIE DETAILS ----- \n\n";
	        cout << "\t Movie Title: " << LIST[count - 1].getTitle() << endl;
	        cout << "\t Movie Synopsis: " << LIST[count - 1].getSynopsis() << endl;
	        cout << "\t MPAA Rating: " << LIST[count - 1].getMPAArating() << endl;
	        cout << "\t Genre: " << LIST[count - 1].getGenre() << endl;
	        cout << "\n\t Director: " << LIST[count - 1].getDirector().getfname() << " " << LIST[count - 1].getDirector().getlname() << ", " << LIST[count - 1].getDirector().getgender() << endl;
	        cout << "\t Main Actor/s: " << LIST[count - 1].getActor().getfname() << " " << LIST[count - 1].getActor().getlname() << ", " << LIST[count - 1].getActor().getgender() << endl;
	
		    do {
			        cout << "\n\t Do you want to add another movie? (Y | N): ";
			        cin >> choice;
			        choice = toupper(choice);
			        if (choice != 'Y' && choice != 'N') 
					{
			            cout << "\n\t Invalid input! Please enter Y or N." << endl;
			        }
			        cin.ignore(); // clear the newline character left in the buffer by cin
		        } while (choice != 'Y' && choice != 'N');
		        
	    } while (choice == 'Y');
	    
	    cout << "\n\t < YOUR LIST OF MOVIES > \n\n";
	    for (int i = 0; i < count; ++i) 
		{
	        cout << "\t MOVIE #" << (i + 1) << " \n\n";
	        cout << "\t Movie Title: " << LIST[i].getTitle() << endl;
	        cout << "\t Movie Synopsis: " << LIST[i].getSynopsis() << endl;
	        cout << "\t MPAA Rating: " << LIST[i].getMPAArating() << endl;
	        cout << "\t Genre: " << LIST[i].getGenre() << endl;
	        cout << "\n0\t Director: " << LIST[i].getDirector().getfname() << " " << LIST[i].getDirector().getlname() << ", " << LIST[i].getDirector().getgender() << endl;
	        cout << "\t Main Actor/s: " << LIST[i].getActor().getfname() << " " << LIST[i].getActor().getlname() << ", " << LIST[i].getActor().getgender() << endl;
	    }
	
	    return 0;
	}

