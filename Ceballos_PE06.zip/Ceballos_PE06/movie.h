/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#ifndef MOVIE_H
	#define MOVIE_H
	
	#include <iostream>
	#include <string.h>
	#include "Person.h"
	
	using namespace std;
	
	class Movie
	{
		// class movie elements / attributes
		private:
		string movie_title;
		string synopsis;
		string mpaa_rating;
		string genre;
		
		// class movie member attributes - objects of class Person
		Person director;
		Person actor;
		
		// class movie methods and constructor
		public:
			
		// default constructor
		Movie(){}
			
		Movie(string TITLE, string SYNOPSIS, string RATING, string GENRE, Person DIRECTOR, Person ACTOR)
		{
			movie_title = TITLE;
			synopsis = SYNOPSIS;
			mpaa_rating = RATING;
			genre = GENRE;
			director = DIRECTOR;
			actor = ACTOR;
		}
		
		// class movie get method
		void setTitle(string TITLE)
		{
			movie_title = TITLE;
		}
		
		void setSynopsis(string SYNOPSIS)
		{
			synopsis = SYNOPSIS;
		}
		
		void setMPAArating(string RATING)
		{
			mpaa_rating = RATING;
		}
		
		void setGenre(string GENRE)
		{
			genre = GENRE;
		}
		
		// class movie set method
		string getTitle() const 
		{
			return movie_title;
		}
		
		string getSynopsis() const 
		{
			return synopsis;
		}
		
		string getMPAArating() const 
		{
			return mpaa_rating;
		}
		
		string getGenre() const 
		{
			return genre;
		}
		
		// Methods for director and actor
	    Person getDirector() const 
		{ 
			return director; 
		}
		
	    void setDirector(Person DIRECTOR) 
		{ 
			director = DIRECTOR; 
		}
	
	    Person getActor() const 
		{ 
			return actor; 
		}
	    
		void setActor(Person ACTOR) 
		{ 
			actor = ACTOR; 
		}
	};
	
	#endif 
