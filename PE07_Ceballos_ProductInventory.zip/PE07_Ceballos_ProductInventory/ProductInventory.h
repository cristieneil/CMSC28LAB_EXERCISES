/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#ifndef PRODUCTINVENTORY_H
	#define PRODUCTINVENTORY_H	
	
	#include <iostream>
	#include <string.h>
	
	using namespace std;
	
	// STEP 1: DEFINE THE PRODUCT CLASS
	class PRODUCT 
	{
		// class  elements / attributes
		private:
		string pname;
		string brand;
		float price;
		int qty;
		string desc;
		string color;
		string category;
		string model;
		
		// class PRODUCT methods and constructors
		public:
			
		// default constructor
		PRODUCT(){}
		
		PRODUCT(string PNAME, string BRAND, float PRICE, int QTY, string DESC, string COLOR, string CATEGORY, string MODEL)
		{
			pname = PNAME;
			brand = BRAND;
			price = PRICE;
			qty = QTY;
			desc = DESC;
			color = COLOR;
			category = CATEGORY;
			model = MODEL;
		}
		
		// CLASS PRODUCT SET METHODS
		void setPname(string PNAME)
		{
			pname = PNAME;
		}
		
		void setBrand(string BRAND)
		{
			brand = BRAND;
		}
		
		void setPrice(float PRICE)
		{
			price = PRICE;
		}
		
		void setQTY(int QTY)
		{
			qty = QTY;
		}	
		
		void setDesc(string DESC)
		{
			desc = DESC;
		}
		
		void setColor(string COLOR)
		{
			color = COLOR;
		}
		
		void setCategory(string CATEGORY)
		{
			category = CATEGORY;
		}
		
		void setModel(string MODEL)
		{
			model = MODEL;
		}
		
		// CLASS PRODUCT GET METHODS
		string getPname() const 
		{
			return pname;
		}
		
		string getBrand() const 
		{
			return brand;
		}
		
		float getPrice() const 
		{
			return price;
		}
		
		int getQTY() const 
		{
			return qty;
		}
		
		string getDesc() const 
		{
			return desc;
		}
		
		string getColor() const 
		{
			return color;
		}
		
		string getCategory() const 
		{
			return category;
		}
		
		string getModel() const 
		{
			return model;
		}
	};
	
	
	// STEP 2: DEFINE THE CLOTHING CLASS INHERITING FROM PRODUCT
	class CLOTHING : public PRODUCT  // child class #1
	{
	    // class CLOTHING unique attributes
		private:
	    string size;
	    string material;
	
	    // class CLOTHING methods and constructors
		public:
			
	    // default constructor
	    CLOTHING(){}
	
	    CLOTHING(string PNAME, string BRAND, float PRICE, int QUANTITY, string DESC, string COLOR, string CATEGORY, string MODEL, string SIZE, string MATERIAL) 
		{
	        setPname(PNAME);
	        setBrand(BRAND);
	        setPrice(PRICE);
	        setQTY(QUANTITY);
	        setDesc(DESC);
	        setColor(COLOR);
	        setCategory(CATEGORY);
	        setModel(MODEL);
	        size = SIZE;
	        material = MATERIAL;
	    }
		
		// CLASS CLOTHING SET METHODS
		void setSize(string SIZE)
		{
			size = SIZE;
		}
		
		void setMaterial(string MATERIAL)
		{
			material = MATERIAL;
		}
		
		// CLASS CLOTHING GET METHODS
		string getSize() const
		{
			return size;
		}
		
		string getMaterial() const
		{
			return material;
		}	
	};
	
	// STEP 3: DEFINE THE ELECTRONICS CLASS INHERITING FROM PRODUCT
	class ELECTRONICS : public PRODUCT  // child class #2
	{
    	// class ELECTRONICS unique attributes
		private:
		    string specs;
		    string warranty;
		
	    // class ELECTRONICS methods and constructors
		public:
			
	    // default constructor
	    ELECTRONICS(){}
	
	    ELECTRONICS(string PNAME, string BRAND, float PRICE, int QTY, string DESC, string COLOR, string CATEGORY, string MODEL, string SPECS, string WARRANTY) 
		{
	        setPname(PNAME);
	        setBrand(BRAND);
	        setPrice(PRICE);
	        setQTY(QTY);
	        setDesc(DESC);
	        setColor(COLOR);
	        setCategory(CATEGORY);
	        setModel(MODEL);
	        specs = SPECS;
	        warranty = WARRANTY;
	    }
		
		// CLASS ELECTRONICS SET METHODS
		void setSpecs(string SPECS)
		{
			specs = SPECS;
		}
		
		void setWarranty(string WARRANTY)
		{
			warranty = WARRANTY;
		}
		
		// CLASS ELECTRONICS GET METHODS
		string getSpecs() const
		{
			return specs;
		}
		
		string getWarranty() const
		{
			return warranty;
		}	
	};
	
	#endif
