/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L 
	PROGRAMMING EXERCISE 07 - OOP 3 INHERITANCE AND ENCAPSULATION
	A C++ PROGRAM THAT SHOWS A CLASS HIERARCHY FOR MANAGING PRODUCTS IN A STORE'S INVENTORY, FOCUSING ON INHERITANCE AND ENCAPSULATION. */
	
	#include <iostream>
	#include <string>
	#include <limits>
	#include <cctype>
	#include "ProductInventory.h" // add as header file
	
	using namespace std;
	
	// program header and desc
	void program_desc() 
	{
	    cout << "\n\t This program will ask the user to input what kind of product they" << endl;
	    cout << "\t would like to list. This program also shows managing products \n\t in a store's inventory. \n" << endl;
	    cout << "............................................................................. \n" << endl;
	
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 22 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	}
	
	// function for error handling for price and quantity
	float correctPrice() 
	{
		float price;
		    
		while (true) 
		{
		    cout << "\t Enter Price: PHP ";
		    cin >> price;
		        
		    // checks if user-input is a negative number
		    if (cin.fail() || price < 0) 
			{
		        cout << "\n\t Invalid input! Please type in positive values only." << endl;
		        cin.clear(); // clear the error flag
		        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
		    } 
				
			else 
			{
		        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard any extra input
		        return price;
		    }
		}
	}
	
	int correctQuantity() 
	{
		int qty;
		    
		while (true) 
		{
		    cout << "\t Enter Quantity: ";
		    cin >> qty;
		        
		    // checks if user-input is a negative number
		    if (cin.fail() || qty < 0) 
			{
		        cout << "\n\t Invalid input! Please type in positive numbers only." << endl;
		        cin.clear(); // clear the error flag
		        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
		    } 
				
			else 
			{
		        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard any extra input
		        return qty;
		    }
		}
	}
	
	// function for user-input for electronics
	ELECTRONICS electronicDetails() 
	{
	    string pname, brand, desc, color, category, model, specs, warranty;
	    float price;
	    int qty;
	
	    cout << "\n\t < PRODUCT TYPE : ELECTRONICS > \n" << endl;
	
	    cout << "\t Enter Product Name: ";
	    cin.ignore(); // to clear the input buffer
	    getline(cin, pname);
	
	    cout << "\t Enter Product Brand: ";
	    getline(cin, brand);
	
	    price = correctPrice();
	
	    qty = correctQuantity();
	
	    cout << "\t Enter Product Description: ";
	    getline(cin, desc);
	
	    cout << "\t Enter Color: ";
	    getline(cin, color);
	
	    cout << "\t Enter Category (Electronics / Clothing): ";
	    getline(cin, category);
	
	    cout << "\t Enter Product Model: ";
	    getline(cin, model);
	
	    cout << "\t Enter Technical Specifications: ";
	    getline(cin, specs);
	
	    cout << "\t Enter Warranty (e.g. 1 year, 6 months): ";
	    getline(cin, warranty);
	
	    return ELECTRONICS(pname, brand, price, qty, desc, color, category, model, specs, warranty);
	}
	
	// function for user-input for clothing
	CLOTHING clothingDetails() 
	{
	    string pname, brand, desc, color, category, model, size, material;
	    float price;
	    int qty;
	
	    cout << "\n\t < PRODUCT TYPE : CLOTHING > \n" << endl;
	
	    cout << "\t Enter Product Name: ";
	    cin.ignore(); // to clear the input buffer
	    getline(cin, pname);
	
	    cout << "\t Enter Product Brand: ";
	    getline(cin, brand);
	
	    price = correctPrice();
	
	    qty = correctQuantity();
	
	    cout << "\t Enter Product Description: ";
	    getline(cin, desc);
	
	    cout << "\t Enter Color: ";
	    getline(cin, color);
	
	    cout << "\t Enter Category (Electronics / Clothing): ";
	    getline(cin, category);
	
	    cout << "\t Enter Product Model: ";
	    getline(cin, model);
	
	    cout << "\t Enter Size (e.g. XS, S, M, L, XL, XXL): ";
	    getline(cin, size);
	
	    cout << "\t Enter Material/s (e.g. cotton, polyester): ";
	    getline(cin, material);
	
	    return CLOTHING(pname, brand, price, qty, desc, color, category, model, size, material);
	}
	
	// MAIN PROGRAM
	int main() 
	{
	    program_desc();
	
	    // variable declaration | under product:
	    char product;
	
		// lets the user  decide which one they'd like to fill in first
		cout << "\n\t Hi! What would you like to input first?";
		cout << "\n\t -- Type E for Electronics, C for Clothing: ";
		while (true) 
		{
		    cin >> product;
		    product = toupper(product); // to convert user-input to uppercase
		
		    if (product == 'E' || product == 'C') 
			{
		        break; // valid choice, exit loop
		    } 
			
			else 
			{
		        cout << "\n\t Invalid choice! Enter E or C only: ";
		    }
		}
		
		// STEP 4: CREATE INSTANCES OF CLOTHING AND ELECTRONICS
		ELECTRONICS electronics;
		CLOTHING clothing;
		
		// if the user chooses E - they'll fill electronics first then clothing
		if (product == 'E') 
		{
		    electronics = electronicDetails(); // fill in information for electronics first
		    clothing = clothingDetails();
		} 
		
		// if the user chooses C - they'll fill clothing first then electronics
		else if (product == 'C') 
		{
		    clothing = clothingDetails(); // fill in information for clothing first
		    electronics = electronicDetails();
		} 
	
		// STEP 5: PRINT DETAILS OF EACH PRODUCT
	    cout << "\n\t -------------- PRODUCTS DETAILS --------------" << endl;
	    
	    // printing / displaying electronic details
	    cout << "\n\t < ELECTRONICS PRODUCT DETAILS >" << endl;
	    cout << "\t Product Name: " << electronics.getPname() << endl;
	    cout << "\t Brand: " << electronics.getBrand() << endl;
	    cout << "\t Price: PHP " << electronics.getPrice() << endl;
	    cout << "\t Quantity: " << electronics.getQTY() << endl;
	    cout << "\t Product Description: " << electronics.getDesc() << endl;
	    cout << "\t Color: " << electronics.getColor() << endl;
	    cout << "\t Category: " << electronics.getCategory() << endl;
	    cout << "\t Product Model: " << electronics.getModel() << endl;
	    cout << "\t Technical Specifications: " << electronics.getSpecs() << endl;
	    cout << "\t Warranty: " << electronics.getWarranty() << endl;
	
		cout << "\n\t ----------------------------------------------" << endl;
	
	    // printing / displaying clothing details
	    cout << "\n\t < CLOTHING PRODUCT DETAILS >" << endl;
	    cout << "\t Product Name: " << clothing.getPname() << endl;
	    cout << "\t Brand: " << clothing.getBrand() << endl;
	    cout << "\t Price: PHP " << clothing.getPrice() << endl;
	    cout << "\t Quantity: " << clothing.getQTY() << endl;
	    cout << "\t Product Description: " << clothing.getDesc() << endl;
	    cout << "\t Color: " << clothing.getColor() << endl;
	    cout << "\t Category: " << clothing.getCategory() << endl;
	    cout << "\t Product Model: " << clothing.getModel() << endl;
	    cout << "\t Size: " << clothing.getSize() << endl;
	    cout << "\t Material: " << clothing.getMaterial() << endl;
	
	    return 0;
	}
