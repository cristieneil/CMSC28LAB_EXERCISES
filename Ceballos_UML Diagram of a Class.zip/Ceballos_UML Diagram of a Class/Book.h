#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include <string> 

using namespace std;

class Book 
{
    // class and its member variables and attributes (set as private)
    private:
        string Title;
        string Author;
        string ISBN;
        string Publisher;
    
    public:
        // constructors and methods (set as public)
    
        // default constructor
        Book() {}
    
        // constructor #1: title
        Book(string bktitle) 
        {
            Title = bktitle;
            Author = "BTS"; // Use double quotes for string literals
            ISBN = "978-1250326751";
            Publisher = "FlatIron Books";
        }
    
        // constructor #2: title and author
        Book(string bktitle, string bkauthor) 
        {
            Title = bktitle;
            Author = bkauthor;
            ISBN = "978-1250326751";
            Publisher = "FlatIron Books";
        }
    
        // constructor #3: title, author, and ISBN
        Book(string bktitle, string bkauthor, string bkisbn) 
        {
            Title = bktitle;
            Author = bkauthor;
            ISBN = bkisbn;
            Publisher = "FlatIron Books";
        }
    
        // constructor with all parameters
        Book(string bktitle, string bkauthor, string bkisbn, string bkpublisher) 
        {
            Title = bktitle;
            Author = bkauthor;
            ISBN = bkisbn;
            Publisher = bkpublisher;
        }
    
        // methods to get and set member variables
        string getTitle() 
        { 
            return Title; 
        }
    
        string getAuthor() 
        { 
            return Author; 
        }
    
        string getISBN() 
        { 
            return ISBN; 
        }
    
        string getPublisher() 
        { 
            return Publisher; 
        }
    
        void setTitle(string bktitle) 
        { 
            Title = bktitle; 
        }
    
        void setAuthor(string bkauthor) 
        { 
            Author = bkauthor; 
        }
    
        void setISBN(string bkisbn) 
        { 
            ISBN = bkisbn; 
        }
    
        void setPublisher(string bkpublisher) 
        { 
            Publisher = bkpublisher; 
        }
    
        // method to view book details
        
        void view() 
        {
            cout << "\n\t Title: " << Title << endl;
            cout << "\t Author: " << Author << endl;
            cout << "\t ISBN: " << ISBN << endl;
            cout << "\t Publisher: " << Publisher << endl; 
        }
};

#endif

