#include <iostream>
#include <string> 
#include "Book.h" // added Book.h as library to this program

using namespace std;

int main() 
{
    string title, author, isbn, publisher;
 
    // program desc
    cout << "\n\t This program will let us test and use all of the defined methods and " << endl;
    cout << "\t constructors found in our header file <Book.h> \n" << endl;
    cout << "............................................................................. \n" << endl;
    
    // about the programmer: name, date done, subject number
    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 11 2024 | SUBJ: CMSC 28 \n" << endl;
    cout << "============================================================================= \n" << endl;
    
    cout << "\t < USING THE CONSTRUCTORS AND METHODS > " << endl;
    
    // create an instance for class Book and pre-determined values
    Book bk ("Beyond the Story: 10-Year Record of BTS", "BTS", "978-1250326751", "FlatIron Books");
    
    // display the initial list from header file
    cout << "\n\t INITIAL BOOK DETAILS (from header file) \n" << endl;
    cout << "\t Title: " << bk.getTitle() << endl;
    cout << "\t Author: " << bk.getAuthor() << endl;
    cout << "\t ISBN: " << bk.getISBN() << endl;
    cout << "\t Publisher: " << bk.getPublisher() << endl;
    
    // USING THE DIFFERENT CONSTRUCTORS
    Book bk1;  
    
    // input details using the empty constructor
    // this also makes use of the methods such as getting the element and setting the values
    // (e.g. setAuthor and getISBN)
    cout << "\n\t INPUT DETAILS FOR BOOK 1 \n" << endl;
    
    cout << "\t Title: ";
    getline (cin, title);
    bk1.setTitle(title);
    
    cout << "\t Author: ";
    getline (cin, author);
    bk1.setAuthor(author);
    
    cout << "\t ISBN: ";
    getline (cin, isbn);
    bk1.setISBN(isbn);
    
    cout << "\t Publisher: ";
    getline (cin, publisher);
    bk1.setPublisher(publisher);
    
    // display details of book 1
    cout << "\n\t BOOK 1 DETAILS (FROM USER_INPUT) \n" << endl;
    cout << "\t Title: " << bk1.getTitle() << endl;
    cout << "\t Author: " << bk1.getAuthor() << endl;
    cout << "\t ISBN: " << bk1.getISBN() << endl;
    cout << "\t Publisher: " << bk1.getPublisher() << endl;
    
    // defining books using different constructors 
    Book bk2 ("Dance, Dance, Dance");  // using constructor #1 (title only)
    Book bk3 ("SPY X Family Vol. 1", "Tatsuya Endo"); // using constructor #2 (title and author)
    Book bk4 ("1984", "George Orwell", "978-0451524935"); // using constructor #3 (title, author, and ISBN)
    Book bk5 ("Perfect Little Monsters", "Cindy R. X. He", "978-1728293394", "Sourcebooks Fire"); // using constructor #4 (all parameters)

    // DISPLAY BOOK DETAILS
    
    cout << "\n\t ALL BOOK DETAILS: \n" << endl;

    cout << "\t BOOK 1 >" << endl;
    cout << "\t (Using default constructor. Details set through user input.)" << endl;
    bk1.view();

    cout << "\n\n\t BOOK 2 >" << endl;
    cout << "\t (Using constructor #1: Title only)" << endl;
    bk2.view();

    cout << "\n\n\t BOOK 3 >" << endl;
    cout << "\t (Using constructor #2: Title and Author)" << endl;
    bk3.view();

    cout << "\n\n\t BOOK 4 >" << endl;
    cout << "\t (Using constructor #3: Title, Author, and ISBN)" << endl;
    bk4.view();

    cout << "\n\n\t BOOK 5 >" << endl;
    cout << "\t (Using constructor #4: All parameters)" << endl;
    bk5.view();
    
    return 0;
}

