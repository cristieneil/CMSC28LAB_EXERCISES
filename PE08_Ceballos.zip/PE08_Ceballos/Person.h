/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3 */

	#ifndef PERSON_H
	#define PERSON_H
	
	#include <iostream>
	#include <string.h>
	
	using namespace std;
	
	class Person 
	{
		// CLASS PERSON ATTRIBUTES 
		private:
		string fname;
		string lname;
		char gender;
		string emailAdd;
		string cpNumber;
		
		// class person methods and constructor
		public:
		
		// default constructor
		Person(){}
		
		// constructor with parameter
		Person(string FIRSTNAME, string LASTNAME, char GENDER, string EMAIL, string PNUM)
		{
			fname = FIRSTNAME;
			lname = LASTNAME;
			gender = GENDER;
			emailAdd = EMAIL;
			cpNumber = PNUM; // phone number
		}
		
		// CLASS PERSON SET METHODS
		void setfname(string FIRSTNAME)
		{
			fname = FIRSTNAME;
		}
		
		void setlname(string LASTNAME)
		{
			lname = LASTNAME;
		}
		
		void setgender(char c)
		{
			if ((c == 'M') || (c == 'F'))
			{
				gender = c;
			} 
			
			else
			{
				cout << "\n\t Invalid gender!!! \n" << endl;
			}
		}
		
		void setemail(string EMAIL)
		{
			emailAdd = EMAIL;
		}
		
		void setpnum(string PNUM)	
		{
			cpNumber = PNUM;
		}
		
		// CLASS PERSON GET METHODS
		string getfname() const 
		{
			return fname;
		}
		
		string getlname() const 
		{
			return lname;
		}

		char getgender()
		{
			return gender;
		}	
		
		string getemail() const
		{
			return emailAdd;
		}
		
		string getpnum() 
		{
			return cpNumber;
		}
	};
	
	#endif  // PERSON.H
