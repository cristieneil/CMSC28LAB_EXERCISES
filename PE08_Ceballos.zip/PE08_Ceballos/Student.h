/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3 */

	#ifndef STUDENT_H
	#define STUDENT_H
	
	#include <iostream>
	#include <string>
	#include "Person.h" // add as header file
	
	using namespace std;
	
	class Student : public Person // subclass of person.h
	{
	    // CLASS STUDENT PRIVATE ATTRIBUTE
		private:
		string studentNum; // private to student - student number
		    
		public:
	    string course;
	    string department;
	    string college;
	    
	    // default constructor
	    Student(){}
	    
	    // constructor with parameters
	    Student(string FIRSTNAME, string LASTNAME, char GENDER, string EMAIL, string PNUM, string SNUM, string COURSE, string DEPT, string COLLEGE)
	        : Person(FIRSTNAME, LASTNAME, GENDER, EMAIL, PNUM) // call person constructor
	    {
	        studentNum = SNUM;
	        course = COURSE;
	        department = DEPT;
	        college = COLLEGE;
	    }
	    
	    // CLASS STUDENT SET METHODS
	    void setsnum(string SNUM)
	    {
	        studentNum = SNUM;
	    }
	    
	    void setcourse(string COURSE)
	    {
	        course = COURSE;
	    }
	    
	    void setdept(string DEPT)
	    {
	        department = DEPT;
	    }
	    
	    void setcollege(string COLLEGE)
	    {
	        college = COLLEGE;
	    }
	    
	    // CLASS STUDENT GET METHODS
	    string getsnum() const 
	    {
	        return studentNum;
	    }
	    
	    string getcourse() const
	    {
	        return course;
	    }
	    
	    string getdept() const
	    {
	        return department;
	    }
	    
	    string getcollege() const
	    {
	        return college;
	    }        
	};
	
	#endif // STUDENT_H
