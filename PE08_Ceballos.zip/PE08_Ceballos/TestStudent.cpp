/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L 
	PROGRAMMING EXERCISE 08 - OOP 4 INHERITANCE
	A C++ PROGRAM THAT SHOWS HOW TO CREATE CHILD CLASSES, HOW TO CREATE AN INSTANCE OF CHILD CLASSES AND HOW TO ASSIGN VALUES 
	TO THE CHILD CLASS ATTRIBUTES, AND HOW TO EXTRACT/ RETRIEVE THE VALUES OF THESE ATTRIBUTES. */
	
	#include <iostream>
	#include <string>
	#include <limits>
	#include <cctype>
	#include "Person.h" // add as header file
	#include "Student.h" // add as header file
	
	using namespace std;
	
	// program header and desc
	void program_desc() 
	{
	    cout << "\n\t This program will ask the student to enter their personal information" << endl;
	    cout << "\t for their enrollment form in UP Mindanao :) \n" << endl;
	    cout << "............................................................................. \n" << endl;
	
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 30 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	}
	
	// check if the gender input is correct
	char valid_gender() 
	{
	    char gender;
	    
	    while (true) 
		{
	        cout << "\t Gender (F | M): ";
	        cin >> gender;
	        gender = toupper(gender);
	        
	        if (gender != 'F' && gender != 'M') 
			{
	            cout << "\n\t Invalid gender! Input a valid character." << endl;
	            cin.clear(); // clear error flags
	            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
	        } 
			
			else 
			{
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear input buffer
	            break;
	        }
	    }
	    
	    return gender;
	}
	
	// MAIN PROGRAM
	int main() 
	{
		string fname, lname, email, cpnum;
		string snum, course, dept, college;
		char gender;
		
	    program_desc();
	    
	    cout << "\n\t STUDENT ENROLLMENT FORM" << endl;
	    cout << "\n\t -------------- ENTER YOUR INFORMATION --------------" << endl;
	    
	    // get student's info
		cout << "\n\t First Name: ";
	    getline(cin, fname);
	
	    cout << "\t Last Name: ";
	    getline(cin, lname);
	
	    gender = valid_gender();
	    
	    cout << "\t Email Address: ";
	    getline(cin, email);
	    
	    cout << "\t Phone Number: ";
	    getline(cin, cpnum);
	    
	    cout << "\t Student Number: ";
	    getline(cin, snum);
	    
	    cout << "\t Course: ";
	    getline(cin, course);
	    
	    cout << "\t Department (ex. Mathematics, Physics and Computer Science): ";
	    getline(cin, dept);
	    
	    cout << "\t College (ex. Science and Mathematics): ";
	    getline(cin, college);

		// create instance for class student
	    Student STUDENT;
	    STUDENT.setfname(fname);
	    STUDENT.setlname(lname);
	    STUDENT.setgender(gender);
	    STUDENT.setemail(email);
	    STUDENT.setpnum(cpnum);
	    STUDENT.setsnum(snum);
	    STUDENT.setcourse(course);
	    STUDENT.setdept(dept);
	    STUDENT.setcollege(college);
	    
	    cout << "\n\n\t --- Data submitted. Thank you for filling up the form. ---" << endl;
	    
	    // display all info
	    
	    cout << "\n\n\t Hi " << STUDENT.getfname() << " " << STUDENT.getlname() << "! Welcome to UP Mindanao and congratulations! We are pleased to inform you that you are";
	    cout << "\n\t admitted in the " << STUDENT.getcourse() << " under the Department of " << STUDENT.getdept() << " College of " << STUDENT.getcollege() << ". Your Student number is " << STUDENT.getsnum() << "." << endl;
		
		cout << "\n\t CONTACT INFORMATION: " << endl;
		cout << "\t Email Address: " << STUDENT.getemail() << endl;
		cout << "\t Phone Number: " << STUDENT.getpnum() << endl;
		
		return 0;
	}  
