/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L 
	PROGRAMMING EXERCISE 08 - OOP 4 INHERITANCE
	A C++ PROGRAM THAT SHOWS HOW TO CREATE CHILD CLASSES, HOW TO CREATE AN INSTANCE OF CHILD CLASSES AND HOW TO ASSIGN VALUES 
	TO THE CHILD CLASS ATTRIBUTES, AND HOW TO EXTRACT/ RETRIEVE THE VALUES OF THESE ATTRIBUTES. */
	
	#include <iostream>
	#include <string>
	#include <limits>
	#include <cctype>
	#include <iomanip>
	#include "Person.h" // add as header file
	#include "Employees.h" // add as header file
	
	using namespace std;
	
	// program header and desc
	void program_desc() 
	{
	    cout << "\n\t This program will ask the employee to enter their personal information" << endl;
	    cout << "\t alongside their monthly salary for record/tracking purposes. \n" << endl;
	    cout << "............................................................................. \n" << endl;
	
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 30 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	}
	
	// check if the gender input is correct
	char valid_gender() 
	{
	    char gender;
	    
	    while (true) 
		{
	        cout << "\t Gender (F | M): ";
	        cin >> gender;
	        gender = toupper(gender);
	        
	        if (gender != 'F' && gender != 'M') 
			{
	            cout << "\n\t Invalid gender! Input a valid character." << endl;
	            cin.clear(); // clear error flags
	            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discard invalid input
	        } 
			
			else 
			{
				cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear input buffer
	            break;
	        }
	    }
	    
	    return gender;
	}
	
	// to check if the inputted value for salary is correct
	float valid_salary() 
	{
	    float salary;
	    
	    while (true) 
		{
	        cout << "\t Your Monthly Salary: PHP ";
	        
	        // checks if user-input is greater than zero
	        if (!(cin >> salary) || salary < 0) 
			{
	            cout << "\n\t Invalid input! Please enter a positive value.\n";
	            cin.clear(); // clear error flags
	            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // discardinvalid input
	        } 
			
			else 
			{
	            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear input buffer
	            break;
	        }
	    }
	    
	    return salary;
	}
	
	// MAIN PROGRAM
	int main() 
	{
		string fname, lname, email, cpnum;
		string empnum, position, office;
		float salary;
		char gender;
		
	    program_desc();
	    
	    cout << "\n\t EMPLOYEE MONTHLY SALARY" << endl;
	    cout << "\n\t -------------- ENTER YOUR INFORMATION --------------" << endl;
	    
	    // get employee's info
		cout << "\n\t First Name: ";
	    getline(cin, fname);
	
	    cout << "\t Last Name: ";
	    getline(cin, lname);
	
	    gender = valid_gender();
	    
	    cout << "\t Email Address: ";
	    getline(cin, email);
	    
	    cout << "\t Phone Number: ";
	    getline(cin, cpnum);
	    
	    cout << "\t Employee Number: ";
	    getline(cin, empnum);
	    
	    cout << "\t Current Position: ";
	    getline(cin, position);
	    
	    cout << "\t Office/Unit (ex. Marketing): ";
	    getline(cin, office);
	    
	    salary = valid_salary();

		// create instance for class employees
	    Employees EMPLOYEE;
	    EMPLOYEE.setfname(fname);
	    EMPLOYEE.setlname(lname);
	    EMPLOYEE.setgender(gender);
	    EMPLOYEE.setemail(email);
	    EMPLOYEE.setpnum(cpnum);
	    EMPLOYEE.setempnum(empnum);
	    EMPLOYEE.setpos(position);
	    EMPLOYEE.setoffice(office);
	    EMPLOYEE.setsalary(salary);
	    
	    cout << "\n\t --- Data submitted. We've successfully recorded your information." << endl;
	    
	    // display all info
	    cout << "\n\n\t -------------- EMPLOYEE'S RECORD --------------" << endl;

	    cout << "\n\n\t Complete Name: " << EMPLOYEE.getfname() << " " << EMPLOYEE.getlname();
	    cout << "\n\t Gender: " << EMPLOYEE.getgender();
	    cout << "\n\t Email Address: " << EMPLOYEE.getemail();
	    cout << "\n\t Phone Number: " << EMPLOYEE.getpnum();
	    cout << "\n\t Current Position: " << EMPLOYEE.getpos();
		cout << "\n\t Office/Unit: " << EMPLOYEE.getoffice();
		cout << "\n\t Monthly Salary: PHP " << fixed << setprecision(2) << EMPLOYEE.getsalary() << endl; // to print up to 2 decimal values

		return 0;
	}  
