/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3 */

	#ifndef	EMPLOYEES_H
	#define EMPLOYEES_H
	
	#include <iostream>
	#include <string>
	#include "Person.h" // add as header file
	
	using namespace std;
	
	class Employees : public Person // subclass of person.h
	{
	    // CLASS EMPLOYEES PRIVATE ATTRIBUTE
		private:
		string empNum; // private to employees - employee number
		    
		public:
	    string position;
	    string office;
	    float salary;
	    
	    // default constructor
	    Employees(){}
	    
	    // constructor with parameters
	    Employees(string FIRSTNAME, string LASTNAME, char GENDER, string EMAIL, string PNUM, string EMPNUM, string POSITION, string OFFICE, float SALARY)
	        : Person(FIRSTNAME, LASTNAME, GENDER, EMAIL, PNUM) // call person constructor
	    {
	        empNum = EMPNUM;
	        position = POSITION;
	        office = OFFICE;
	        salary = SALARY;
	    }
	    
	    // CLASS EMPLOYEES SET METHODS
	    void setempnum(string EMPNUM)
	    {
	        empNum = EMPNUM;
	    }
	    
	    void setpos(string POSITION)
	    {
	        position = POSITION;
	    }
	    
	    void setoffice(string OFFICE)
	    {
	        office = OFFICE;
	    }
	    
	    void setsalary(float SALARY)
	    {
	        salary = SALARY;
	    }
	    
	    // CLASS STUDENT GET METHODS
	    string getempnum() const 
	    {
	        return empNum;
	    }
	    
	    string getpos() const
	    {
	        return position;
	    }
	    
	    string getoffice() const
	    {
	        return office;
	    }
	    
	    float getsalary() const
	    {
	        return salary;
	    }        
	};
	
	#endif // EMPLOYEES_H
