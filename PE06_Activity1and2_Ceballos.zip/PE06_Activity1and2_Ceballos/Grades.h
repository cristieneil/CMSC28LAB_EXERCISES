/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#include <iostream>
	#include <string> 
	
	using namespace std;
	
	class Grades
	{
		private:
		string subject;
		int grade;
		
		public:
			
		Grades(){}
		
		Grades(string SUBJECT, int GRADE)
		{
			subject = SUBJECT;
			grade = GRADE;
		}
		
		void setsubject(string SUBJECT)
		{
			subject = SUBJECT;
		}
		
		string getsubject()
		{
			return subject;
		}

	    void setgrade(int GRADE)
	    {
	        if (GRADE <= 0 || GRADE > 100)
	        {
	            cout << "\n\t Invalid input. Grade should be between 0 and 100! \n" << endl;
	        }
	        
	        else
	        {
	            grade = GRADE;
	            
	            if (GRADE < 60)
	            {
	                cout << "\n\t YOU HAVE A FAILING GRADE :( " << endl;
	            }
	            
	            else
	            {
	                cout << "\n\t YOU HAVE A PASSING GRADE :) " << endl;
	            }
	        }
	    }
		
		int getgrade()
		{
			return grade;
		}
		
		void display()
		{
			cout << "\t Subject = " << subject << endl;
			cout << "\t Grade for this subject = " << grade << endl;
		}
	};
