/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#include <iostream>
	#include <string> 
	#include "ALBUM.h" // HEADER FILE
	
	// MAIN PROGRAM
	int main()
	{
		// creating an instance and populating with pre=determined values
		ALBUM album("BTS", "Love Yourself: Tear", 749.99);
		
		album.view();
		
		return 0;
	}
	
