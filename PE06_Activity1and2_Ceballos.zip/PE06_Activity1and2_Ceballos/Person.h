#include <iostream>

using namespace std;

class Persons
{
	private:
	int age;
	char gender;
	
	public:
	
	Person(int newage, char c)
	{
		age = newage;
		gender = c;
	}
	
	void setage(int newage)
	{
		if(newage >= 0)
		{
			age = newage;
		} 
	
		else
		{
			cout << "\n\t Invalid age!!! \n" << endl;
		}
	}
	
	int getage()
	{
		return age;
	}
	
	void setgender(char c)
	{
		if ((c == 'M') || (c == 'F'))
		{
			gender = c;
		} 
		
		else
		{
			cout << "\n\t Invalid gender!!! \n" << endl;
		}
	}
	
	char getgender()
	{
		return gender;
	}
	
	void view()
	{
		cout << "\n\t Age = " << age << endl;
		cout << "\t Gender = " << gender << endl;
	}
};
