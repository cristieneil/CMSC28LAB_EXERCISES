/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#include <iostream>
	#include <string> 
	
	using namespace std;
	
	class ALBUM 
	{
		private:
		string group;
		string album_name;
		float price;
		
		public:
			
		ALBUM(string GROUP, string ALBUM_NAME, float PRICE)
		{
			group = GROUP;
			album_name = ALBUM_NAME;
			price = PRICE;
		}	
		
		void view()
		{
			cout << "\n\t\t ALBUM DETAILS \n" << endl;
			cout << "================================================== \n";
			cout << "\n\t Group name: " << group << endl;
			cout << "\n\t Album Name: " << album_name << endl;
			cout << "\n\t Price: PHP " << price << endl;
		}
	};

	// MAIN PROGRAM
	int main()
	{
		// creating an instance and populating with pre=determined values
		ALBUM album("BTS", "Love Yourself: Tear", 749.99);
		
		album.view();
		
		return 0;
	}
