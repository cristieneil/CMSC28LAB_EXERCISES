/* WRITTEN BY: CRISTIENEIL CEBALLOS  | K-3L */

	#include <iostream>
	#include <string> 
	#include <ctype.h>
	#include "Person.h" // person.h as header file 1
	#include "Grades.h" // grades.h as header file 2
	
	using namespace std;
	
	int main() 
	{
	    int age;
	    char c;
	    string subj;
	    int grade;
	
	    // create individual instance for the two files
	    Persons student;
	    Grades g;
	
	    // program header and desc
	    cout << "\n\t This program will ask the user (student) to input their age, " << endl;
	    cout << "\t gender, subject, and grade - also determines if it's passing or not \n" << endl;
	    cout << "............................................................................. \n" << endl;
	
	    // about the programmer: name, date done, subject number
	    cout << "\t CREATED BY: CRISTIENEIL CEBALLOS | DATE: MAY 15 2024 | SUBJ: CMSC 28 \n" << endl;
	    cout << "============================================================================= \n" << endl;
	
	
	    cout << "\n\t Input Age: ";
	    cin >> age;
	    student.setage(age);
	
	    cout << "\t Input Gender: ";
	    cin >> c;
	    c = toupper(c); // to convert user-inout to uppercase
	    student.setgender(c);
	
	    cin.ignore(); // Ignore the newline character left in the input buffer
	
	    cout << "\t Input Subject Name: ";
	    getline(cin, subj);
	    g.setsubject(subj);
	
	    cout << "\t Input Subject Grade: ";
	    cin >> grade;
	    g.setgrade(grade);
	
	    cout << "\n\t OUTPUT" << endl;
	    cout << "\n\t Age = " << student.getage() << endl;
	    cout << "\t Gender = " << student.getgender() << endl;
	    cout << "\t Subject = " << g.getsubject() << endl;
	    cout << "\t Grade = " << g.getgrade() << endl;
	
	    cout << "\n\t OUTPUT DISPLAY USING METHOD VIEW" << endl;
	    student.view();
	    g.display();
	
	    return 0;
	}
